import React from 'react';

const PersonList = (props) => {
    return (
        <div>
            <ul>
                {props.people.map(person => (
                    <li key={person.dni}>
                        {person.firstname} {person.lastname}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default PersonList;