import React from 'react';
import { useState } from 'react';

const useCounter = (increment = 1) => {
  const [count, setCount] = useState(0);

  const incrementCount = () => {
    setCount(count + increment);
  };

  const decrementCount = () => {
    setCount(count - increment);
  };

  return { count, incrementCount, decrementCount };
};



function MyComponent() {
  const { count, incrementCount, decrementCount } = useCounter(5);

  return (
    <div>
      <p>{count}</p>
      <button onClick={incrementCount}>Increment</button>
      <button onClick={decrementCount}>Decrement</button>
    </div>
  );
}

export default MyComponent;


/*


const RepresentarDato = ({ data }) => {
  return <h1>{data}</h1>;
};

export default RepresentarDato;
*/




/*
const PersonList = (props) => {
  return (
      <div>
          <ul>
              {props.people.map(person => (
                  <li key={person.dni}>
                      {person.firstname} {person.lastname}{person.dni}
                  </li>
              ))}
          </ul>
      </div>
  );
}

const App = () => {
  const people = [
      {firstname: "demo", lastname: "Demo", dni: 1234},
      {firstname: "demo2", lastname: "demo2", dni: 456},
      {firstname: "demo3", lastname: "demo3", dni: 789}
  ];

  return (
      <div>
          <PersonList people={people} />
      </div>
  );
}*/